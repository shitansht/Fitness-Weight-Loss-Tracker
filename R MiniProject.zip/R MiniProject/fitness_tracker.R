
# ============================================================
# FITNESS AND WEIGHT LOSS TRACKER
# MCA R PROGRAMMING PROJECT
# MENU-DRIVEN APPLICATION
# ============================================================

# STEP 1: LOAD DATASET

file_name <- "C:/Users/Shitansh/Downloads/R MiniProject/fitness_weight_loss_tracker_1000_rows.csv"

if (!file.exists(file_name)) {
  stop("CSV not found. Check the file path.")
}

fitness <- read.csv(file_name, stringsAsFactors = FALSE)
fitness$Date <- as.Date(fitness$Date)
fitness <- fitness[order(fitness$Date), ]

cat("\n====================================\n")
cat(" FITNESS AND WEIGHT LOSS TRACKER\n")
cat("====================================\n")
cat("Dataset loaded successfully!\n")
cat("Total records:", nrow(fitness), "\n")

# STEP 2: MENU FUNCTION

show_menu <- function() {
  cat("\n====================================\n")
  cat("       MAIN MENU\n")
  cat("====================================\n")
  cat("1. View First 6 Records\n")
  cat("2. View Dataset Information\n")
  cat("3. Check Missing and Duplicate Values\n")
  cat("4. View Fitness Summary Statistics\n")
  cat("5. Analyze Weight Change\n")
  cat("6. View Weight Progress Graph\n")
  cat("7. View Calorie Intake Graph\n")
  cat("8. View Exercise Calories Burned Graph\n")
  cat("9. View Daily Steps Histogram\n")
  cat("10. View Workout Duration Graph\n")
  cat("11. Compare Workout Types\n")
  cat("12. Compare Steps by Workout Type\n")
  cat("13. Compare Calorie Intake and Exercise Calories\n")
  cat("14. View Correlation Analysis\n")
  cat("15. Export Cleaned Dataset\n")
  cat("16. Export Fitness Summary Report\n")
  cat("17. View All Graphs\n")
  cat("0. Exit\n")
  cat("====================================\n")
}

# STEP 3: APPLICATION LOOP

repeat {
  
  show_menu()
  
  choice <- suppressWarnings(
    as.integer(readline("Enter your choice (0-17): "))
  )
  
  if (is.na(choice)) {
    cat("Invalid input! Enter a number from 0 to 17.\n")
    next
  }
  
  if (choice == 0) {
    cat("\nThank you for using Fitness Tracker!\n")
    break
  }
  
  # OPTION 1: FIRST SIX RECORDS
  else if (choice == 1) {
    cat("\nFirst 6 Records:\n")
    print(head(fitness))
  }
  
  # OPTION 2: DATASET INFORMATION
  else if (choice == 2) {
    cat("\nDataset Dimensions:\n")
    print(dim(fitness))
    
    cat("\nColumn Names:\n")
    print(names(fitness))
    
    cat("\nDataset Structure:\n")
    str(fitness)
  }
  
  # OPTION 3: DATA QUALITY
  else if (choice == 3) {
    cat("\nMissing Values:\n")
    print(colSums(is.na(fitness)))
    
    cat("\nDuplicate Rows:\n")
    print(sum(duplicated(fitness)))
  }
  
  # OPTION 4: SUMMARY STATISTICS
  else if (choice == 4) {
    cat("\n===== FITNESS SUMMARY =====\n")
    
    cat("\nWeight (kg):\n")
    print(summary(fitness$Weight_kg))
    
    cat("\nCalories Consumed:\n")
    print(summary(fitness$Calories_Intake_kcal))
    
    cat("\nExercise Calories Burned:\n")
    print(summary(fitness$Calories_Burned_Exercise_kcal))
    
    cat("\nDaily Steps:\n")
    print(summary(fitness$Daily_Steps))
    
    cat("\nWorkout Duration:\n")
    print(summary(fitness$Workout_Duration_Min))
  }
  
  # OPTION 5: WEIGHT CHANGE
  else if (choice == 5) {
    starting_weight <- fitness$Weight_kg[1]
    ending_weight <- fitness$Weight_kg[nrow(fitness)]
    weight_change <- ending_weight - starting_weight
    
    cat("\n===== WEIGHT CHANGE ANALYSIS =====\n")
    cat("Starting recorded weight:", starting_weight, "kg\n")
    cat("Ending recorded weight:", ending_weight, "kg\n")
    cat("Weight change:", round(weight_change, 2), "kg\n")
    
    if (weight_change < 0) {
      cat("The ending weight is lower than the starting weight.\n")
    } else if (weight_change > 0) {
      cat("The ending weight is higher than the starting weight.\n")
    } else {
      cat("The starting and ending weights are equal.\n")
    }
  }
  
  # OPTION 6: WEIGHT GRAPH
  else if (choice == 6) {
    plot(
      fitness$Date, fitness$Weight_kg,
      type = "l",
      main = "Weight Progress Over Time",
      xlab = "Date",
      ylab = "Weight (kg)"
    )
  }
  
  # OPTION 7: CALORIE INTAKE GRAPH
  else if (choice == 7) {
    plot(
      fitness$Date, fitness$Calories_Intake_kcal,
      type = "l",
      main = "Daily Calorie Intake",
      xlab = "Date",
      ylab = "Calories Consumed (kcal)"
    )
  }
  
  # OPTION 8: EXERCISE CALORIES GRAPH
  else if (choice == 8) {
    plot(
      fitness$Date, fitness$Calories_Burned_Exercise_kcal,
      type = "l",
      main = "Calories Burned During Exercise",
      xlab = "Date",
      ylab = "Calories Burned (kcal)"
    )
  }
  
  # OPTION 9: DAILY STEPS HISTOGRAM
  else if (choice == 9) {
    hist(
      fitness$Daily_Steps,
      main = "Distribution of Daily Steps",
      xlab = "Daily Steps",
      ylab = "Number of Records"
    )
  }
  
  # OPTION 10: WORKOUT DURATION GRAPH
  else if (choice == 10) {
    plot(
      fitness$Date, fitness$Workout_Duration_Min,
      type = "l",
      main = "Workout Duration Over Time",
      xlab = "Date",
      ylab = "Workout Duration (minutes)"
    )
  }
  
  # OPTION 11: WORKOUT TYPE COMPARISON
  else if (choice == 11) {
    average_duration <- aggregate(
      Workout_Duration_Min ~ Workout_Type,
      data = fitness,
      FUN = mean
    )
    
    cat("\nAverage Workout Duration by Type:\n")
    print(average_duration)
    
    barplot(
      average_duration$Workout_Duration_Min,
      names.arg = average_duration$Workout_Type,
      las = 2,
      main = "Average Workout Duration by Type",
      xlab = "Workout Type",
      ylab = "Average Minutes"
    )
  }
  
  # OPTION 12: STEPS BY WORKOUT TYPE
  else if (choice == 12) {
    average_steps_type <- aggregate(
      Daily_Steps ~ Workout_Type,
      data = fitness,
      FUN = mean
    )
    
    cat("\nAverage Daily Steps by Workout Type:\n")
    print(average_steps_type)
    
    barplot(
      average_steps_type$Daily_Steps,
      names.arg = average_steps_type$Workout_Type,
      las = 2,
      main = "Average Steps by Workout Type",
      xlab = "Workout Type",
      ylab = "Average Daily Steps"
    )
  }
  
  # OPTION 13: CALORIE COMPARISON
  else if (choice == 13) {
    plot(
      fitness$Calories_Intake_kcal,
      fitness$Calories_Burned_Exercise_kcal,
      main = "Calorie Intake vs Exercise Calories",
      xlab = "Calories Consumed (kcal)",
      ylab = "Exercise Calories Burned (kcal)"
    )
  }
  
  # OPTION 14: CORRELATION ANALYSIS
  else if (choice == 14) {
    weight_steps_correlation <- cor(
      fitness$Weight_kg,
      fitness$Daily_Steps,
      use = "complete.obs"
    )
    
    weight_calories_correlation <- cor(
      fitness$Weight_kg,
      fitness$Calories_Intake_kcal,
      use = "complete.obs"
    )
    
    cat("\n===== CORRELATION ANALYSIS =====\n")
    
    cat("Weight vs Daily Steps:",
        round(weight_steps_correlation, 3), "\n")
    
    cat("Weight vs Calorie Intake:",
        round(weight_calories_correlation, 3), "\n")
    
    cat("\nCorrelation ranges from -1 to +1.\n")
    cat("Correlation does not prove causation.\n")
  }
  
  # OPTION 15: EXPORT CLEANED DATA
  else if (choice == 15) {
    write.csv(
      fitness,
      "fitness_data_cleaned.csv",
      row.names = FALSE
    )
    
    cat("Cleaned dataset exported successfully!\n")
    cat("File: fitness_data_cleaned.csv\n")
  }
  
  # OPTION 16: EXPORT SUMMARY REPORT
  else if (choice == 16) {
    fitness_summary <- data.frame(
      Metric = c(
        "Average Weight (kg)",
        "Highest Weight (kg)",
        "Lowest Weight (kg)",
        "Average Calories Consumed",
        "Average Exercise Calories Burned",
        "Average Daily Steps",
        "Average Workout Duration (minutes)",
        "Total Workout Duration (minutes)"
      ),
      Value = c(
        mean(fitness$Weight_kg, na.rm = TRUE),
        max(fitness$Weight_kg, na.rm = TRUE),
        min(fitness$Weight_kg, na.rm = TRUE),
        mean(fitness$Calories_Intake_kcal, na.rm = TRUE),
        mean(fitness$Calories_Burned_Exercise_kcal, na.rm = TRUE),
        mean(fitness$Daily_Steps, na.rm = TRUE),
        mean(fitness$Workout_Duration_Min, na.rm = TRUE),
        sum(fitness$Workout_Duration_Min, na.rm = TRUE)
      )
    )
    
    write.csv(
      fitness_summary,
      "fitness_summary_report.csv",
      row.names = FALSE
    )
    
    cat("Summary report exported successfully!\n")
    cat("File: fitness_summary_report.csv\n")
  }
  
  # OPTION 17: ALL GRAPHS
  else if (choice == 17) {
    old_par <- par(no.readonly = TRUE)
    par(mfrow = c(2, 2))
    
    plot(
      fitness$Date, fitness$Weight_kg,
      type = "l",
      main = "Weight Progress",
      xlab = "Date", ylab = "Weight (kg)"
    )
    
    plot(
      fitness$Date, fitness$Calories_Intake_kcal,
      type = "l",
      main = "Calorie Intake",
      xlab = "Date", ylab = "Calories (kcal)"
    )
    
    hist(
      fitness$Daily_Steps,
      main = "Daily Steps Distribution",
      xlab = "Steps", ylab = "Frequency"
    )
    
    barplot(
      aggregate(
        Workout_Duration_Min ~ Workout_Type,
        data = fitness,
        FUN = mean
      )$Workout_Duration_Min,
      names.arg = aggregate(
        Workout_Duration_Min ~ Workout_Type,
        data = fitness,
        FUN = mean
      )$Workout_Type,
      las = 2,
      main = "Average Workout Duration",
      ylab = "Minutes"
    )
    
    par(old_par)
  }
  
  # INVALID MENU CHOICE
  else {
    cat("Invalid choice! Please enter a number from 0 to 17.\n")
  }
}

